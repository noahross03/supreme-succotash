﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Auth.Models;

namespace Auth.Data
{
    public class ShoeContext : DbContext
    {
        public ShoeContext (DbContextOptions<ShoeContext> options)
            : base(options)
        {
        }

        public DbSet<Auth.Models.Shoe> Shoe { get; set; }
    }
}
