﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Auth.Models
{
    public class Shoe
    {
        public int ID { get; set; }
        public string brand { get; set; }
        public string Model { get; set; }
        public int price { get; set; }
    }
}
